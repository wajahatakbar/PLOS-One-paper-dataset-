clear all
clc 
%function ImagProcess(BlockSize,StartFrameStr, EndFrameStr,PSd)
BlockSize = 10;
StartFrameStr = '1'
EndFrameStr = '200' % 1065

PSd = 10
vobj = VideoReader('Wildlife.avi');

nFrames = vobj.NumberOfFrames;
vidHeight = vobj.Height;
vidWidth = vobj.Width;

fff = 2
    img = imresize(read(vobj,fff-1), [500,500]);
    Ad = rgb2gray(img);
    A = double(Ad);
    
    fkk = 1;
    EndFrame = 800;
for fk = fff : 2 + EndFrame + 1
    B = A;
    Bd = Ad;
    img2 = img;

    img = imresize(read(vobj,fk), [500 , 500]);
    Ad = rgb2gray(img);
    A = double(Ad);
    

mbsize = BlockSize;    %%%%Block Size
p = PSd;          %%%%P-Search distance

[height width] = size(A);
mbheight = height/mbsize;
mbwidth = width/mbsize;

[motionVect, computations] = motionEstSESTSS(B, A, mbsize, p);
motionV = motionVect(1,:) .* motionVect(1,:) + motionVect(2,:) .* motionVect(2,:);
mvx= (reshape (motionVect(1,:),  mbwidth, mbheight))';
mvy= (reshape (motionVect(2,:), mbwidth, mbheight))';

mv= (reshape (motionV, mbwidth, mbheight))';
mv2 = repelem(mv,10,10);
bmv2 = (mv2 >10);
subplot(2,3,1), imshow(img)

subplot(2,3,2), imshow(bmv2)


timg = img;

timg(:,:,1) = img(:,:,1) .*  uint8(bmv2);
timg(:,:,2) = img(:,:,2) .*  uint8(bmv2);
timg(:,:,3) = img(:,:,3) .*  uint8(bmv2);
subplot(2,3,3), imshow(timg)

subplot(2,2,3), bar3(mv)
subplot(2,2,4),quiver(mvx(:,50:-1:1),mvy(:,50:-1:1))

pause(.001);


 MV10 (fkk,:) = motionV(1,:);    

 fkk = fkk + 1;
% if fk > 40
%     return
% end
end
PSd





