clear all
clc 


% 
% for i = 2: 6
%     vobj = VideoReader(nnn(i-1));    
%     ex1(i,:) = {vobj.Name  vobj.Duration vobj.FrameRate vobj.NumFrames vobj.Height vobj.Width }
% end



for i = 2:5

    if i ==1
        fname = 'paris_cif.avi';        
    elseif i ==2
        fname = 'Aeroplans.mp4'        
    elseif i ==3
        fname = 'Wildlife.avi'
    elseif i == 4
        fname = 'Pool.mp4'
    else 
        fname = 'Mixmasterfile.mpg'
    end
    vobj = VideoReader(fname);    


%function ImagProcess(BlockSize,StartFrameStr, EndFrameStr,PSd)
BlockSize = 10;
StartFrameStr = '1'
EndFrameStr = '200' % 1065

PSd = 10;

% -------------------------------------------------------------------------
fff = 2
img = imresize(read(vobj,fff-1), [500,500]);
Ad = rgb2gray(img);
A = double(Ad);
    
fkk = 1;
EndFrame = 800;
MMM = 0;
th1 = 15;
for fk = fff : 5 + EndFrame + 1
        B = A;
        Bd = Ad;
        img2 = img;

        img = imresize(read(vobj,fk), [500 , 500]);
        Ad = rgb2gray(img);
        A = double(Ad);
        mbsize = BlockSize;    %%%%Block Size
        p = PSd;          %%%%P-Search distance
        [height width] = size(A);
        mbheight = height/mbsize;
        mbwidth = width/mbsize;
        [motionVect, computations] = motionEstSESTSS(B, A, mbsize, p);
        MMM = MMM + 1
        motionV = motionVect(1,:) .* motionVect(1,:) + motionVect(2,:) .* motionVect(2,:);
    
        motionVall(MMM,1:2500) = motionV(1:2500);
        MotionMean(MMM) = mean(motionV);
        MotionMax(MMM)  = max(motionV);
        MotionMin(MMM)  = min(motionV);
        MotionMB(MMM) = sum(motionV  > th1);
        MotionDiff(MMM) = sum((abs(diff(motionV))) > th1)/2;
        
        MotionCase(MMM) = 0;
        if MotionMean(MMM) < th1 | MotionMB(MMM) <5
            MotionCase(MMM) = 1;
        elseif  MotionMean(MMM) >= th1  & MotionDiff(MMM) > 25
                MotionCase(MMM) = 2;
        elseif MotionMin(MMM) <=5  & MotionMax(MMM) > th1 &  MotionMB(MMM) > 15
                MotionCase(MMM) = 3;
        else
                MotionCase(MMM) = 4;
            
            
        end
     
        
        
    
%         mvx= (reshape (motionVect(1,:),  mbwidth, mbheight))';
%         mvy= (reshape (motionVect(2,:), mbwidth, mbheight))';
%         mv= (reshape (motionV, mbwidth, mbheight))';
%         mv2 = repelem(mv,10,10);
%         bmv2 = (mv2 >10);
%         subplot(2,2,1), imshow(img)
%         subplot(2,2,2), bar3(mv)
%         subplot(2,2,3), imshow(bmv2)
%         subplot(2,2,4), imshow(img .* uint8(bmv2))
%         pause(.001);
%         MV10 (fkk,:) = motionV(1,:);    
%         fkk = fkk + 1;
%         if fk > 4
%             return
%         end
end


% plot(MotionMean)
% hold on
% plot (MotionMax,'^')
% plot (MotionMax)
% plot (MotionMin,'v')
% legend ([ 'Mean '; 'maximum'; ''; 'Minimum'])
% xlabel 'Frames'
% ylabel 'Intensity of motion'
%%
fdata = [ MotionMean ; MotionMax; MotionMin ; MotionMB ; MotionDiff]';
fdata(:,6:2500+5) = motionVall(:,1:2500);
xlswrite(strcat(fname,'.xlsx'),fdata)
end





